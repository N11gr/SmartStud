# Aufbau von index.html

Die gesamte App steckt in einer Datei. Reihenfolge im Code:

## 1. `<head>` und `<style>`
- Google Fonts, Farb-Variablen in `:root` (z. B. `--bg1` Dunkelblau, `--gold`, `--cyan`, `--soft`)
- Styles für alle Bereiche, kommentiert mit Überschriften wie `/* Noten */`, `/* Prüfungsblatt */`,
  `/* Chat-Assistent */`. Spätere Regeln überschreiben frühere (z. B. dunkles Fensterdesign `.kal`).

## 2. `<script>` – Daten
- `MATH` – Mathe-Lehrplan (Kapitel → Themen mit `t` Titel, `s` Lerntext, `k` Übungen)
- `DE_LEKT`, `DE_EPO`, `DE_SCHREIB` – Deutsch; `GEO` – Geographie; `SPORT`, `SCHNELL` – Sport
- `INTRO` – Einführungstexte pro Thema
- `EXTRA` – Skizzen und Beispiele pro Thema (`sk` = Skizzen-Beschreibung)
- `CARDEX` – aufklappbare Übung pro Lernkarte (Anzahl muss zur Zahl der Karten passen)
- `EXAM` – Prüfungsaufgaben (Mathe) mit Teilaufgaben `[Frage, BE, Lösung]`
- `SUBJ_RAW` / `SUBJECTS` – alle Fächer; `byId` – Zugriff per Kürzel (`ma`, `de`, `sp`, `geo` …)
- Ferien und Feiertage (Bayern), `TYPES` – Prüfungsarten und Farben

## 3. `<script>` – Speicher und Zustand
- `settings` – Name, Fächer (`subs`), Abifächer (`abi`), LK (`lk`), Termine (`events`),
  Hausaufgaben (`hw`), Noten (`grades`), Notenrechner (`pts`)
- `plans[fachId]` – erledigte Themen, Notizen, KI-Inhalte
- `view` – aktuelle Seite und geöffnete Bereiche
- `save()` speichert im Claude-Konto (falls vorhanden) und immer im `localStorage`

## 4. `<script>` – Darstellung
- `render()` baut die Seite neu; `go({...})` wechselt die Seite
- Seiten: `renderHome` (Dashboard), `renderPlan`, `renderCal`, `renderNoten`, `renderProfile`,
  `renderSetup`, `renderSubject`, `renderTopic`
- Bausteine: `soonHTML` (Steht an), `avgHTML` (Notendurchschnitt), `countdownHTML`, `nextHTML`,
  `calHTML`, `hwHTML`, `calcHTML`, `npCard`, `gBody`, `gChart`, `sketch()` (alle SVG-Skizzen)
- Prüfungsblatt: `openSheet`, `bindCanvas`, `strokeOn`, `applyZoom` (Stift, Zoom, Seiten)
- KI: `chatSend`, `aiRow`, `aiAsk` (nur aktiv, wenn `window.claude` vorhanden ist)
- Bedienung: ein zentraler Klick-Handler (`document.addEventListener("click", …)`) mit
  `data-…`-Attributen, eigener Bestätigungsdialog `askConfirm`

## Tipps für die Zusammenarbeit mit KI-Assistenten
- Immer die aktuelle `index.html` aus GitHub mitgeben.
- Kleine, gezielte Änderungen verlangen („ändere nur Funktion X“) statt die Datei neu schreiben zu lassen.
- Nach jeder Änderung lokal testen, dann pushen.
