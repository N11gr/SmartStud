# SmartStud – Abi-Lernplan

Lern- und Planungs-Webseite fürs bayerische Abitur: Lehrpläne mit Erklärungen, Skizzen und Übungen
(Mathe, Deutsch, Geographie, Sport u. a.), Kalender mit Ferien/Feiertagen, Planung, Hausaufgaben,
Noten mit Diagrammen, Notenrechner, Prüfungsmodus mit DIN-A4-Blatt (Apple Pencil).

## Projektstruktur

```
smartstud/
├── index.html          ← die komplette App (HTML, CSS und JavaScript in einer Datei)
├── package.json        ← Skript zum lokalen Starten (statischer Server)
├── vercel.json         ← Einstellungen für Vercel
├── .gitignore          ← Dateien, die nicht ins Repository gehören
├── README.md           ← diese Anleitung
└── docs/
    └── PROJEKTSTRUKTUR.md  ← Aufbau des Codes (für dich, ChatGPT und Claude)
```

Es gibt **keinen Build-Schritt** und **keine Abhängigkeiten zur Laufzeit**. Bilder und Skizzen sind
als SVG direkt im Code. Einzige externe Quelle: Google Fonts (DM Serif Display, Manrope, Space Grotesk).

## Lokal starten

Variante A – ohne Installation: `index.html` doppelklicken bzw. im Browser öffnen.

Variante B – mit lokalem Server (empfohlen, verhält sich wie online):

```bash
npm install
npm run dev
```

Dann im Browser `http://localhost:3000` öffnen.

## Änderungen veröffentlichen

1. `index.html` ändern und lokal testen.
2. Änderungen auf GitHub hochladen (Commit + Push).
3. Vercel veröffentlicht automatisch die neue Version.

## Wichtig: Unterschiede außerhalb von Claude

Die App wurde als Claude-Artifact gebaut und nutzt dort Zusatzfunktionen von claude.ai.
Auf Vercel oder lokal gilt:

| Funktion | in Claude | auf Vercel / lokal |
|---|---|---|
| Lerninhalte, Skizzen, Übungen, Prüfungen, Kalender, Noten, Notenrechner, Prüfungsblatt | ✅ | ✅ |
| Speichern | im Claude-Konto (geräteübergreifend) | nur im Browser des Geräts (localStorage) |
| Chat-Assistent, KI-Hilfe, „Lerninhalt/Aufgaben erstellen“ | ✅ (über das Claude-Kontingent des Nutzers) | ❌ ausgeblendet – bräuchte einen eigenen Server mit API-Schlüssel |

Die App erkennt automatisch, ob die Claude-Funktionen verfügbar sind (`window.claude`), und
fällt sonst auf den Browser-Speicher zurück. Es muss dafür nichts geändert werden.

**Sicherheit:** Das Login-Passwort wird nur im Browser geprüft und schützt die Seite nicht wirklich.
Niemals einen API-Schlüssel in `index.html` schreiben – er wäre für jeden sichtbar.
